===========
row2plot
===========

row2plot provides the facilty to covert your row data into different graph such as hist, kdeplot. 

often looks like this::

    #!/usr/bin/env python

    from row2plot import row2hist
    from row2plot import row2kde


